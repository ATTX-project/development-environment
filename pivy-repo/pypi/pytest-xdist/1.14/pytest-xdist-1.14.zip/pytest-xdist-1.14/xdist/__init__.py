__all__ = ['__version__']
from xdist._version import version as __version__
